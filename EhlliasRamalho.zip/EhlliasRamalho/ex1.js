let elementos = [10,20,30,40];
elementos.shift()
elementos.shift()
elementos.shift()
console.log(`O Item que soubrou da lista é ${elementos}.`);